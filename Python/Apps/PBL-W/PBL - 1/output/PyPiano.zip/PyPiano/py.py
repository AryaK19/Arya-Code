# a = 12
# b ={ "a":2,"l":3}
# print(b["a"])

# a = "cd2"

# print(a[0].upper() + a[1] + str(int(a[2])+3))


# print(f"a is {a}")


# for i in range(-150,151,30):
    # print(i)

import numpy as np 
arr = np.array([[0,1,2,3],[1,2,3,4],[1,2,3,4]])

print(arr[:,2])